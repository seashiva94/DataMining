#########################
# Decision Tree program #
#########################


To run the decision tree program, execute the following comand:

	python decision_tree.py <method> <filename>

# example:

	python decision_tree.py GINI iris_data.csv

* method: can be either GINI, or ENTROPY to use GINI index and entropy gain respectively
* filemane: can be either data/iris_data.csv, data/wine_data.csv or data/breastcancer_data.csv, depending on the dataset the user chooses to run the code on.


  
