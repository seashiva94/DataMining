The Knn.py code generates random data for both the gaussian and uniform
data egnerators for K = 3, 30, 300, 3000 
and finds the 5-nearest neighbours for each of the points
and calculates how many times each point has been in the 5 neighbours and generates a plot for the data.

The plot is saved in a pdf file

by default the code runs foruniform data for K = 3 and 30 
To change values of K or the data generation method, 
change the lines 98, 99 and 100

to change the value of N , change line 96 
