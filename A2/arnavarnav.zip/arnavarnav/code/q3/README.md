Kmeans.py

The code runs Kmeans on the data set provided

the code taked the following command line arguments in the order

1. filename, the file name to be used
2. method,: whether to use kmeans or elkans
3. distance function
4. K: the number of clusters

the codeassumes that the last column inthe csv file is the actual labels of the data

To run for birch dataset uncomment the lines 261 to 282

